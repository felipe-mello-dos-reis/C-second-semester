/* Não modifique este arquivo. */

#ifndef BST_H
#define BST_H

#include <stdbool.h>

typedef struct bst BST;

BST *bst_create();

void bst_destroy(BST *bst);

void bst_insert(BST *bst, int value);

void bst_dfs_inorder(const BST *bst);  // ordena

#endif // BST_H
